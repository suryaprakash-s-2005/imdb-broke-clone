const API_KEY = "d2952fbd";
const BASE_URL = "https://www.omdbapi.com/";

const popularTitles = [
  "Harry Potter and the Goblet of Fire",
  "Interstellar",
  "Attack on Titan",
  "I Want to Eat Your Pancreas",
  "La La Land",
  "The Dark Knight",
  "Iron Man",
  "Spider-Man",
  "Naruto: Shippuden",
  "Weathering with You",
  "One Piece",
  "Harry Potter and the Sorcerer's Stone",
  "The Matrix",
  "Bleach",
  "Avatar",
  "Fight Club",
  "Demon Slayer: Kimetsu no Yaiba",
  "Titanic",
  "Stranger Things",
  "Finding Nemo",
  "Dragon Ball Z",
  "Vinland Saga",
  "Inception",
  "The Shawshank Redemption",
  "Avengers",
  "Naruto",
  "Jujutsu Kaisen",
  "Solo Leveling",
  "Harry Potter and the Deathly Hallows: Part 1",
  "Squid Game",
];



export const getPopularMovies = async () => {
  try {
    const results = await Promise.all(
      popularTitles.map((title) =>
        fetch(
          `${BASE_URL}?apikey=${API_KEY}&t=${encodeURIComponent(title)}`
        ).then((res) => res.json())
      )
    );

    return results.filter((movie) => movie.Response === "True");
  } catch (err) {
    throw err;
  }
};

export const searchMovies = async (query) => {
  try {
    const response = await fetch(
      `${BASE_URL}?apikey=${API_KEY}&s=${encodeURIComponent(query)}`
    );
    const data = await response.json();
    if (data.Response === "True") {
      return data.Search;
    } else {
      throw new Error(data.Error || "No movies found");
    }
  } catch (err) {
    throw err;
  }
};


export const getMovieById = async (id) => {
  try {
    const response = await fetch(
      `${BASE_URL}?apikey=${API_KEY}&i=${id}&plot=full`
    );
    const data = await response.json();
    if (data.Response === "True") {
      return data;
    } else {
      throw new Error(data.Error || "Movie not found");
    }
  } catch (err) {
    throw err;
  }
};
